
<!DOCTYPE html>
<html lang="">
<head>
<meta http-equiv="Content-Type" content="text/php; charset=utf-8" />
<link rel="stylesheet"  href="estilosIndex.css">
<link rel="shortcut icon" href="img/favicon.png" type="image/png" />
<title>Formulario</title>
</head>

<body id="ocho">
<div id="contenedor">
<h2 id="titulo">Formulario</h2>
    <table>
        <tr class="color1">
            <th colspan="3">DATOS PERSONALES</th>
        </tr>
        <tr class="color2">
            <td>Nombre</td>
            <td>Apellidos</td>
            <td>Correo electronico</td>
        </tr>
        <tr class="color1">
            <td class="resp">
                        </td>
            <td class="resp">
                            </td>
            <td class="resp">
                            </td>
        </tr>
        <tr class="color2">
            <th colspan="3">ENCUESTA</th>
        </tr>
        <tr class="color1">
            <td>Consulta</td>
            <td>Ayuda</td>
            <td>Comentario</td>
        </tr>
        <tr class="color2">
            <td class="resp">
                            </td>
            <td class="resp">
                            </td>
            <td class="resp">
                            </td>
        </tr>

    </table><br/>
    <a href="index.html">Volver</a>
    </div>
