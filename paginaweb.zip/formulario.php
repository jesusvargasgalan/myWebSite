Hola <?php echo htmlspecialchars($_GET['nombre']); ?>.
Su apellido es <?php echo htmlspecialchars($_GET['apellido']); ?>.
Su contrasenia  es <?php echo htmlspecialchars($_GET['contrasenia']);?>.
La página le pareció <?php echo htmlspecialchars($_GET['gusto']); ?>.
